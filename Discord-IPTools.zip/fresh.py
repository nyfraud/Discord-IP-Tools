# -*- coding: utf-8 -*-
import discord
from discord import app_commands
from pythonping import ping
import json
import os
import requests
import socket
import time

TOKEN = ""  # Replace with your real bot token

intents = discord.Intents.default()
intents.message_content = True  # FIXED: needed to read messages for login flow
client = discord.Client(intents=intents)
tree = app_commands.CommandTree(client)

# FIXED: use absolute path for users_file to avoid working directory issues
users_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "users.txt")
tokens_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tokens.json")

logged_in_users = set()

# Ensure files exist
if not os.path.exists(users_file):
    with open(users_file, "w") as f:
        pass

if not os.path.exists(tokens_file):
    with open(tokens_file, "w") as f:
        json.dump(["A1B2C3-D4E5F6", "G7H8I9-J0K1L2", "M3N4O5-P6Q7R8", "S9T0U1-V2W3X4", "Y5Z6A7-B8C9D0", "E1F2G3-H4I5J6", "K7L8M9-N0O1P2", "Q3R4S5-T6U7V8", "W9X0Y1-Z2A3B4", "C5D6E7-F8G9H0", "I1J2K3-L4M5N6", "O7P8Q9-R0S1T2", "U3V4W5-X6Y7Z8", "A9B0C1-D2E3F4", "G5H6I7-J8K9L0", "M1N2O3-P4Q5R6", "S7T8U9-V0W1X2", "Y3Z4A5-B6C7D8", "E9F0G1-H2I3J4", "K5L6M7-N8O9P0", "Q1R2S3-T4U5V6", "W7X8Y9-Z0A1B2", "C3D4E5-F6G7H8", "I9J0K1-L2M3N4", "O5P6Q7-R8S9T0"], f)

def load_tokens():
    with open(tokens_file, "r") as f:
        return json.load(f)

def save_tokens(tokens):
    with open(tokens_file, "w") as f:
        json.dump(tokens, f)

def save_user(username, password):
    with open(users_file, "a") as f:
        f.write(f"{username}:{password}\n")

def check_credentials(username, password):
    print(f"[DEBUG] Checking credentials for: {username}:{password}")
    if not os.path.exists(users_file):
        print("[DEBUG] users.txt file not found.")
        return False
    with open(users_file, "r") as f:
        lines = f.readlines()
        if not lines:
            print("[DEBUG] users.txt file is empty.")
        for line in lines:
            line_clean = line.strip()
            print(f"[DEBUG] Read line: '{line_clean}'")
            if line_clean == f"{username}:{password}":
                print("[DEBUG] Credentials matched.")
                return True
    print("[DEBUG] No matching credentials found.")
    return False

@tree.command(name="redeem", description="Redeem a token and create an account")
async def redeem(interaction: discord.Interaction, token: str):
    tokens = load_tokens()
    if token not in tokens:
        await interaction.response.send_message("? Invalid token.", ephemeral=True)
        return

    try:
        await interaction.response.send_message("? Token accepted! Check your DMs to continue.", ephemeral=True)

        def check(m):
            return m.author == interaction.user and isinstance(m.channel, discord.DMChannel)

        await interaction.user.send("Please enter your **username**:")
        username_msg = await client.wait_for("message", check=check, timeout=60)

        await interaction.user.send("Now enter your **password**:")
        password_msg = await client.wait_for("message", check=check, timeout=60)

        save_user(username_msg.content.strip(), password_msg.content.strip())
        tokens.remove(token)
        save_tokens(tokens)

        await interaction.user.send("* Account created successfully.")

    except Exception:
        await interaction.followup.send("* Timeout or error. Please try again.", ephemeral=True)

@tree.command(name="login", description="Login using your account")
async def login(interaction: discord.Interaction):
    await interaction.response.send_message("Check your DMs to login.", ephemeral=True)

    def check(m):
        return m.author == interaction.user and isinstance(m.channel, discord.DMChannel)

    try:
        await interaction.user.send("Enter your username:")
        username_msg = await client.wait_for("message", check=check, timeout=60)

        await interaction.user.send("Enter your password:")
        password_msg = await client.wait_for("message", check=check, timeout=60)

        username = username_msg.content.strip()
        password = password_msg.content.strip()

        print(f"[DEBUG] User entered username: '{username}' and password: '{password}'")

        if check_credentials(username, password):
            logged_in_users.add(interaction.user.id)
            await interaction.user.send("* Login successful. You can now use `/help` to see available commands.")
        else:
            await interaction.user.send("* No account found with that username/password. Please `/redeem` a token to register.")

    except Exception as e:
        print(f"[DEBUG] Exception in login: {e}")
        await interaction.user.send("* Timeout or error. Please try again.")

@tree.command(name="listusers", description="List all registered usernames (admin only)")
async def listusers(interaction: discord.Interaction):
    # Optional: restrict access to admins only
    if interaction.user.id != 792363672185602089:
        await interaction.response.send_message("You do not have permission to run this command.", ephemeral=True)
        return

    if not os.path.exists(users_file):
        await interaction.response.send_message("No users registered yet.", ephemeral=True)
        return

    with open(users_file, "r") as f:
        users = [line.split(":", 1)[0] for line in f if line.strip()]
    
    if not users:
        await interaction.response.send_message("No users registered yet.", ephemeral=True)
    else:
        await interaction.response.send_message(f"Registered users:\n" + "\n".join(users), ephemeral=True)

@tree.command(name="geoip", description="Get IP geolocation info (login required)")
async def geoip_cmd(interaction: discord.Interaction, ip_or_domain: str):
    if interaction.user.id not in logged_in_users:
        await interaction.response.send_message("? You must be logged in to use this command. Please use `/login` first.", ephemeral=True)
        return

    try:
        await interaction.response.defer(ephemeral=True)  # Avoid 3s timeout
        response = requests.get(f"https://ipinfo.io/{ip_or_domain}/json", timeout=5)

        if response.status_code != 200:
            raise Exception("Could not retrieve geo data.")

        data = response.json()
        embed = discord.Embed(
            title=f"?? GeoIP Lookup: `{ip_or_domain}`",
            color=discord.Color.purple()
        )

        embed.add_field(name="IP", value=data.get("ip", "N/A"), inline=True)
        embed.add_field(name="City", value=data.get("city", "N/A"), inline=True)
        embed.add_field(name="Region", value=data.get("region", "N/A"), inline=True)
        embed.add_field(name="Country", value=data.get("country", "N/A"), inline=True)
        embed.add_field(name="Location", value=data.get("loc", "N/A"), inline=True)
        embed.add_field(name="Org", value=data.get("org", "N/A"), inline=False)
        embed.set_footer(text="Data from ipinfo.io")

        await interaction.followup.send(embed=embed, ephemeral=True)

    except Exception as e:
        await interaction.followup.send(f"? Error: {str(e)}", ephemeral=True)

@tree.command(name="logout", description="Logout from your account")
async def logout(interaction: discord.Interaction):
    if interaction.user.id in logged_in_users:
        logged_in_users.remove(interaction.user.id)
        await interaction.response.send_message("* You have been logged out.", ephemeral=True)
    else:
        await interaction.response.send_message("* You are not logged in.", ephemeral=True)
        
@tree.command(name="tcpping", description="Test TCP connection to IP:Port (repeats 4 times)")
async def tcp(interaction: discord.Interaction, ip: str, port: int):
    await interaction.response.defer()

    results = []
    for i in range(4):
        try:
            sock = socket.create_connection((ip, port), timeout=2)
            sock.close()
            results.append(f"* Attempt {i+1}: Connection successful")
        except Exception as e:
            results.append(f"* Attempt {i+1}: Failed - {e}")

    embed = discord.Embed(
        title=f"TCP Connection Test - {ip}:{port}",
        description="\n".join(results),
        color=discord.Color.green() if any("?" in r for r in results) else discord.Color.red()
    )
    embed.set_footer(text="TCP test repeated 4 times")
    await interaction.followup.send(embed=embed)

@tree.command(name="help", description="Shows help info (login required)")
async def help_cmd(interaction: discord.Interaction):
    if interaction.user.id not in logged_in_users:
        await interaction.response.send_message("* You must be logged in to use this command. Please use `/login` first.", ephemeral=True)
        return

    embed = discord.Embed(
        title="Help Menu",
        description="Here are the available commands:",
        color=discord.Color.blue()
    )
    embed.add_field(name="/redeem `<token>`", value="Redeem a token and create an account", inline=False)
    embed.add_field(name="/login", value="Login using your credentials", inline=False)
    embed.add_field(name="/logout", value="Logout from your account", inline=False)
    embed.add_field(name="------------------------------------------------", value="", inline=False)
    embed.add_field(name="/ping `<host>`", value="Ping a udp host to check connectivity", inline=False)
    embed.add_field(name="/help", value="Show this help message", inline=False)
    embed.add_field(name="/tcpping `<host>` `<port>`", value="Check if a TCP port is reachable and get RTT", inline=False)
    embed.set_footer(text="Need more help? Contact an admin.")
    embed.add_field(name="/geoip `<ip or domain>`", value="Get geolocation info for an IP address or domain", inline=False)
    await interaction.response.send_message(embed=embed, ephemeral=True)

@tree.command(name="ping", description="Ping a host to check connectivity (login required)")
async def ping_cmd(interaction: discord.Interaction, host: str):
    if interaction.user.id not in logged_in_users:
        await interaction.response.send_message("* You must be logged in to use this command. Please use `/login` first.", ephemeral=True)
        return

    try:
        result = ping(host, count=4, timeout=1)
        success_count = sum(1 for r in result if r.success)
        avg_ms = result.rtt_avg_ms

        embed = discord.Embed(
            title=f"?? Ping Results for `{host}`",
            color=discord.Color.green() if success_count > 0 else discord.Color.red()
        )
        embed.add_field(name="Pings Sent", value="4", inline=True)
        embed.add_field(name="Successful", value=str(success_count), inline=True)
        embed.add_field(name="Average RTT", value=f"{avg_ms:.2f} ms", inline=True)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    except Exception as e:
        await interaction.response.send_message(f"* Error: {str(e)}", ephemeral=True)

@client.event
async def on_ready():
    await tree.sync()
    print(f"* Logged in as {client.user}.")

client.run(TOKEN)
