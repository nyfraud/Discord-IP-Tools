import discord
import asyncio
from discord.ext import tasks

TOKEN = ""  # Replace with your actual bot token

intents = discord.Intents.default()
client = discord.Client(intents=intents)

# Phrases to rotate through
status_phrases = ["Follow ", "Daddy", "@nyfraud", "On", "Instagram"]

@client.event
async def on_ready():
    print(f"? Logged in as {client.user} (ID: {client.user.id})")
    rotate_status.start()

@tasks.loop(seconds=3)
async def rotate_status():
    for phrase in status_phrases:
        await client.change_presence(
            activity=discord.Activity(type=discord.ActivityType.watching, name=phrase)
        )
        await asyncio.sleep(10)

client.run(TOKEN)
